exA = "Kristofferson"
exB = "nosreffotsirK"
exC = "Taste"
exD = "State"
exE = "Dog"
exF = "Cat"
string1 = ""
string2 = ""

def UserInput():
    string1 = input("\nEnter your first String: \n")
    userString1 = CheckinStringInput(string1)
    string2 = input("\nEnter your second String: \n")
    Algorithm(userString1, string2)
    Restart()

def CheckinStringInput(x):
    y = 0
    while y == 0:
        if type(x) == str:
            y =1
            return x;
        else:
            x = input("Error! what you entered was not a string try again:\n")

def CheckAnagram(x ,y):
    i = x.lower().strip()
    j = y.lower().strip()
    if sorted(i) == sorted(j) :
        return True
    else:
        return False

def ReverseString(x):
    rev = ''.join(reversed(x))
    return rev

def CheckPalindromes(x, y):
    if ReverseString(x) == y:
        return True
    else:
        return False

def Algorithm(x,y):
    if CheckAnagram(x,y) == True and CheckPalindromes(x,y) == True:
        print( "\n"+ x + " and " + y + " are Anagrams and are also Palindromes")
    elif CheckAnagram(x,y) == True and CheckPalindromes(x,y) == False:
        print( "\n"+ x + " and " + y + " are Anagrams However, they are NOT Palindromes")
    elif CheckAnagram(x,y) == False and CheckPalindromes(x,y) == True:
        print("\n"+ x + " and " + y + " are NOT Anagrams However, they are Palindromes")
    else:
        print("\n"+ x + " and " + y + " are NOT Anagrams and are NOT Palindromes")
    print("\n")

def Restart():
    string3 = input("Would you like to preform another Comparison?(Type yes otherwise hit any button)\n")
    if string3 == "yes":
        UserInput()
    else:
        print("\nHave a great Day\n")

def main():
    test = input("this is a test")
    x = CheckinStringInput(test)
    UserInput()

main()
